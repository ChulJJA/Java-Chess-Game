package chess;

import java.util.function.BiPredicate;

import chess.ReturnPiece.PieceFile;
import chess.ReturnPiece.PieceType;
import chess.ReturnPlay.Message;

public class King {
	private static boolean hasMoved = false;

	public static Message IsMoveValid(PieceType piece_type, PieceFile cur_file, int cur_rank, PieceFile mov_file, int mov_rank) 
	{
		if(Chess.PieceInBoard(mov_file, mov_rank) == false)
		{
			return Message.ILLEGAL_MOVE;
		}

		PieceFile left_file_bound = null;
		PieceFile right_file_bound = null;

		if(cur_file.ordinal() - 1 >= 0)
		{
			left_file_bound = PieceFile.values()[cur_file.ordinal() - 1];
		}
		if(cur_file.ordinal() + 1 <= 7)
		{
			right_file_bound = PieceFile.values()[cur_file.ordinal() + 1];
		}
		int top_rank_bound = cur_rank + 1;
		int bot_rank_bound = cur_rank - 1;

		if (IsCasling(mov_file, mov_rank)) 
		{
			hasMoved = true;
			return true;
		}

		if (piece_type == PieceType.WK) 
		{
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, left_file_bound, top_rank_bound) || IsValidPosition(mov_file, mov_rank, left_file_bound, top_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, left_file_bound, cur_rank) || IsValidPosition(mov_file, mov_rank, left_file_bound, cur_rank)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, left_file_bound, bot_rank_bound) || IsValidPosition(mov_file, mov_rank, left_file_bound, bot_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, cur_file, top_rank_bound) || IsValidPosition(mov_file, mov_rank, cur_file, top_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, cur_file, bot_rank_bound) || IsValidPosition(mov_file, mov_rank, cur_file, bot_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, right_file_bound, top_rank_bound) || IsValidPosition(mov_file, mov_rank, right_file_bound, top_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, right_file_bound, cur_rank) || IsValidPosition(mov_file, mov_rank, right_file_bound, cur_rank)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, right_file_bound, bot_rank_bound) || IsValidPosition(mov_file, mov_rank, right_file_bound, bot_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
		} 
		else if (piece_type == PieceType.BK) 
		{
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, left_file_bound, top_rank_bound) || IsValidPosition(mov_file, mov_rank, left_file_bound, top_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, left_file_bound, cur_rank) || IsValidPosition(mov_file, mov_rank, left_file_bound, cur_rank)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, left_file_bound, bot_rank_bound) || IsValidPosition(mov_file, mov_rank, left_file_bound, bot_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, cur_file, top_rank_bound) || IsValidPosition(mov_file, mov_rank, cur_file, top_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, cur_file, bot_rank_bound) || IsValidPosition(mov_file, mov_rank, cur_file, bot_rank_bound))
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, right_file_bound, top_rank_bound) || IsValidPosition(mov_file, mov_rank, right_file_bound, top_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, right_file_bound, cur_rank) || IsValidPosition(mov_file, mov_rank, right_file_bound, cur_rank)) 
			{
				hasMoved = true;
				return null;
			}
			if (IsAppropriatePiece(piece_type, mov_file, mov_rank, right_file_bound, bot_rank_bound) || IsValidPosition(mov_file, mov_rank, right_file_bound, bot_rank_bound)) 
			{
				hasMoved = true;
				return null;
			}
		}
		return Message.ILLEGAL_MOVE;
	}

	public boolean IsCasling(PieceFile mov_file, int mov_rank) {

		BiPredicate<Character, Integer> positionW = (c,
				i) -> ((Chess.activeBoard.getCell(c, i).equals("##") || Chess.activeBoard.getCell(c, i).equals("  "))
						&& (mov_file == c && mov_rank == i) && !ChessBoard.wK_Check[i][Character.valueOf(c) - 97]);
		BiPredicate<Character, Integer> positionB = (c,
				i) -> ((Chess.activeBoard.getCell(c, i).equals("##") || Chess.activeBoard.getCell(c, i).equals("  "))
						&& (mov_file == c && mov_rank == i) && !ChessBoard.bK_Check[i][Character.valueOf(c) - 97]);

		char c = getCol();
		if (getChessPieceName().equals("wK") && getCol() > mov_file) {
			if (Chess.activeBoard.getChessPiece('a', 1) instanceof Rook) {
				if (!hasMoved && !((Rook) Chess.activeBoard.getChessPiece('a', 1)).isHasMoved()) {
					if (((Rook) Chess.activeBoard.getChessPiece('a', 1)).isPathClear('a', 1, getCol(), getRow())) {
						--c;
						if (positionW.test(--c, getRow())) {
							Chess.activeBoard.getChessPiece('a', 1).setColRow(++c, 1);
							Chess.activeBoard.initStateOfBoard();
							return true;
						}
					}
				}
			}
		}
		if (getChessPieceName().equals("wK") && getCol() < mov_file) {
			if (Chess.activeBoard.getChessPiece('h', 1) instanceof Rook) {
				if (!hasMoved && !((Rook) Chess.activeBoard.getChessPiece('h', 1)).isHasMoved()) {
					if (((Rook) Chess.activeBoard.getChessPiece('h', 1)).isPathClear('h', 1, getCol(), getRow())) {
						++c;
						if (positionW.test(++c, getRow())) {
							Chess.activeBoard.getChessPiece('h', 1).setColRow(--c, 1);
							Chess.activeBoard.initStateOfBoard();
							return true;
						}
					}
				}
			}
		}
		if (getChessPieceName().equals("bK") && getCol() > mov_file) {
			if (Chess.activeBoard.getChessPiece('a', 8) instanceof Rook) {
				if (!hasMoved && !((Rook) Chess.activeBoard.getChessPiece('a', 8)).isHasMoved()) {
					if (((Rook) Chess.activeBoard.getChessPiece('a', 8)).isPathClear('a', 8, getCol(), getRow())) {
						--c;
						if (positionB.test(--c, getRow())) {
							Chess.activeBoard.getChessPiece('a', 8).setColRow(++c, 8);
							Chess.activeBoard.initStateOfBoard();
							return true;
						}
					}
				}
			}
		}
		if (getChessPieceName().equals("bK") && getCol() < mov_file) {
			if (Chess.activeBoard.getChessPiece('h', 8) instanceof Rook) {
				if (!hasMoved && !((Rook) Chess.activeBoard.getChessPiece('h', 8)).isHasMoved()) {
					if (((Rook) Chess.activeBoard.getChessPiece('h', 8)).isPathClear('h', 8, getCol(), getRow())) {
						++c;
						if (positionB.test(++c, getRow())) {
							Chess.activeBoard.getChessPiece('h', 8).setColRow(--c, 8);
							Chess.activeBoard.initStateOfBoard();
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	public static boolean IsAppropriatePiece(PieceType piece_name, PieceFile file, int rank, PieceFile file_bound, int rank_bound)
    {
        if(file_bound == null || rank_bound == 0)
        {
            return false;
        }

        for(ReturnPiece rp : Chess.return_play.piecesOnBoard)
        {
            if(rp.pieceFile == file && rp.pieceRank == rank)
            {
                if(piece_name == PieceType.WK)
                {
                    if((rp.pieceType.toString().startsWith("B")) || (file == file_bound && rank == rank_bound))
                    {
                        Chess.return_play.piecesOnBoard.remove(rp);
                        return true;
                    }
                }
                else if(piece_name == PieceType.BK)
                {
                    if((rp.pieceType.toString().startsWith("W")) || (file == file_bound && rank == rank_bound))
                    {
                        Chess.return_play.piecesOnBoard.remove(rp);
                        return true;
                    }
                }
            }
        }
        return false;
    }

	private static boolean IsValidPosition(PieceFile file, int rank, PieceFile file_bound, int rank_bound)
    {
        if(file_bound == null || rank_bound == 0)
        {
            return false;
        }

        if(file == file_bound && rank == rank_bound)
        {
            return true;
        }

        return false;
    }
	
	public boolean isHasMoved() 
    {
		return hasMoved;
	}

	public void setHasMoved(boolean hasMoved) 
    {
		this.hasMoved = hasMoved;
	}
}