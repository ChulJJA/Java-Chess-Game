// package chess;

// import chess.ReturnPiece.PieceType;

// public class Pawn extends Piece {
// 	private boolean enPassant = false;
// 	private int numOfEnPassantTurns = 0;

// 	public Pawn(PieceType piece_type, char col, int row) {
// 		super(piece_type, col, row);
// 	}

// 	public boolean IsMoveValid(char curCol, int curRow, char intCol, int intRow) {
// 		char leftColBound = (char) ((Character.valueOf(curCol) - 97) - 1 + 97);
// 		char rightColBound = (char) ((Character.valueOf(curCol) - 97) + 1 + 97);
//         System.out.println(Character.valueOf(curCol) - 97);
// 		int topRowBound = curRow + 1;
// 		int botRowBound = curRow - 1;

// 		if (validEnPassantMove(intCol, intRow))
// 			return true;

// 		if (GetPieceType().equals("wp")) {
// 			// moving forward one square
// 			if (Chess.activeBoard.getCell(curCol, curRow + 1).equals("##")
// 					|| Chess.activeBoard.getCell(curCol, curRow + 1).equals("  ")) {
// 				if (intCol == curCol && intRow == curRow + 1) {
// 					return true;
// 				}
// 			}
// 			// check to move up two squares from initial spot
// 			if (curRow == 2 && (Chess.activeBoard.getCell(curCol, curRow + 2).equals("##")
// 					|| Chess.activeBoard.getCell(curCol, curRow + 2).equals("  "))) {
// 				if (intCol == curCol && intRow == curRow + 2) {
// 					enPassant = true;
// 					return true;
// 				}
// 			}
// 			// check if right move goes out of bounds
// 			// move right to take a piece
// 			if (Chess.activeBoard.getCell((rightColBound), topRowBound).contains("b")) {
// 				if (intCol == rightColBound && intRow == topRowBound) {
// 					return true;
// 				}
// 			}
// 			// check if left move goes out f bounds
// 			// move left to take a piece
// 			if (Chess.activeBoard.getCell((leftColBound), topRowBound).contains("b")) {
// 				if (intCol == leftColBound && intRow == topRowBound) {
// 					return true;
// 				}
// 			}
// 		} else if (getChessPieceName().equals("bp")) {
// 			// moving forward one square
// 			if (Chess.activeBoard.getCell(curCol, curRow - 1).equals("##")
// 					|| Chess.activeBoard.getCell(curCol, curRow - 1).equals("  ")) {
// 				if (intCol == curCol && intRow == curRow - 1) {
// 					return true;
// 				}
// 			}
// 			// check to move up two squares from initial spot
// 			if (curRow == 7 && (Chess.activeBoard.getCell(curCol, curRow - 2).equals("##")
// 					|| Chess.activeBoard.getCell(curCol, curRow - 2).equals("  "))) {
// 				if (intCol == curCol && intRow == curRow - 2) {
// 					enPassant = true;
// 					return true;
// 				}
// 			}
// 			// check if right move goes out of bounds
// 			// move right to take a piece
// 			if (Chess.activeBoard.getCell((rightColBound), botRowBound).contains("w")) {
// 				if (intCol == rightColBound && intRow == botRowBound) {
// 					return true;
// 				}
// 			}
// 			// check if left move goes out f bounds
// 			// move left to take a piece
// 			if (Chess.activeBoard.getCell((leftColBound), botRowBound).contains("w")) {
// 				if (intCol == leftColBound && intRow == botRowBound) {
// 					return true;
// 				}
// 			}
// 		}
// 		return false;
// 	}

// 	/**
// 	 * Used for checkmate, includes allied pieces
// 	 * 
// 	 * @return Returns true or false depending on whether or not move is valid
// 	 */
// 	@Override
// 	public boolean validMoveCheck(char curCol, int curRow, char intCol, int intRow) {
// 		char leftColBound = (char) ((Character.valueOf(curCol) - 97) - 1 + 97);
// 		char rightColBound = (char) ((Character.valueOf(curCol) - 97) + 1 + 97);

// 		int topRowBound = curRow + 1;
// 		int botRowBound = curRow - 1;

// 		if (validEnPassantMove(intCol, intRow))
// 			return true;

// 		if (getChessPieceName().equals("wp")) {
// 			// check if right move goes out of bounds
// 			// move right to take a piece
// 			if (Chess.activeBoard.getCell((rightColBound), topRowBound).contains("##")
// 					|| Chess.activeBoard.getCell((rightColBound), topRowBound).contains("  ")
// 					|| Chess.activeBoard.getCell((rightColBound), topRowBound).contains("w")
// 					|| Chess.activeBoard.getCell((rightColBound), topRowBound).contains("b")) {
// 				if (intCol == rightColBound && intRow == topRowBound) {
// 					return true;
// 				}
// 			}
// 			// check if left move goes out f bounds
// 			// move left to take a piece
// 			if (Chess.activeBoard.getCell((leftColBound), topRowBound).contains("##")
// 					|| Chess.activeBoard.getCell((leftColBound), topRowBound).contains("  ")
// 					|| Chess.activeBoard.getCell((leftColBound), topRowBound).contains("w")
// 					|| Chess.activeBoard.getCell((leftColBound), topRowBound).contains("b")) {
// 				if (intCol == leftColBound && intRow == topRowBound) {
// 					return true;
// 				}
// 			}
// 		} else if (getChessPieceName().equals("bp")) {
// 			// check if right move goes out of bounds
// 			// move right to take a piece
// 			if (Chess.activeBoard.getCell((rightColBound), botRowBound).contains("##")
// 					|| Chess.activeBoard.getCell((rightColBound), botRowBound).contains("  ")
// 					|| Chess.activeBoard.getCell((rightColBound), botRowBound).contains("b")
// 					|| Chess.activeBoard.getCell((rightColBound), botRowBound).contains("w")) {
// 				if (intCol == rightColBound && intRow == botRowBound) {
// 					return true;
// 				}
// 			}
// 			// check if left move goes out f bounds
// 			// move left to take a piece
// 			if (Chess.activeBoard.getCell((leftColBound), botRowBound).contains("##")
// 					|| Chess.activeBoard.getCell((leftColBound), botRowBound).contains("  ")
// 					|| Chess.activeBoard.getCell((leftColBound), botRowBound).contains("b")
// 					|| Chess.activeBoard.getCell((leftColBound), botRowBound).contains("w")) {
// 				if (intCol == leftColBound && intRow == botRowBound) {
// 					return true;
// 				}
// 			}
// 		}
// 		return false;
// 	}

// 	/**
// 	 * Checks for a valid EnPassant move
// 	 * 
// 	 * @param intCol Intended col to move to
// 	 * @param intRow Intended row to move to
// 	 * @return Returns true if valid enpassant move, false otherwise
// 	 */
// 	public boolean validEnPassantMove(char intCol, int intRow) {
// 		char leftCol = getCol();
// 		char rightCol = getCol();

// 		if (getChessPieceName().equals("wp")) {
// 			if (--leftCol >= 'a') {
// 				if (Chess.activeBoard.getChessPiece(leftCol, getRow()) instanceof Pawn) {
// 					if (((Pawn) Chess.activeBoard.getChessPiece(leftCol, getRow())).isEnPassant()) {
// 						if (Chess.activeBoard.getCell(leftCol, getRow()).contains("b")) {
// 							if (intCol == leftCol && intRow == getRow() + 1) {
// 								Chess.activeBoard.getChessPieces()
// 										.remove(Chess.activeBoard.getChessPiece(leftCol, getRow()));
// 								Chess.activeBoard.initStateOfBoard();
// 								return true;
// 							}
// 						}
// 					}
// 				}
// 			}
// 			if (++rightCol <= 'h') {
// 				if (Chess.activeBoard.getChessPiece(rightCol, getRow()) instanceof Pawn) {
// 					if (((Pawn) Chess.activeBoard.getChessPiece(rightCol, getRow())).isEnPassant()) {
// 						if (Chess.activeBoard.getCell(rightCol, getRow()).contains("b")) {
// 							if (intCol == rightCol && intRow == getRow() + 1) {
// 								Chess.activeBoard.getChessPieces()
// 										.remove(Chess.activeBoard.getChessPiece(rightCol, getRow()));
// 								Chess.activeBoard.initStateOfBoard();
// 								return true;
// 							}
// 						}
// 					}
// 				}
// 			}
// 		}
// 		if (getChessPieceName().equals("bp")) {
// 			if (--leftCol >= 'a') {
// 				if (Chess.activeBoard.getChessPiece(leftCol, getRow()) instanceof Pawn) {
// 					if (((Pawn) Chess.activeBoard.getChessPiece(leftCol, getRow())).isEnPassant()) {
// 						if (Chess.activeBoard.getCell(leftCol, getRow()).contains("w")) {
// 							if (intCol == leftCol && intRow == getRow() - 1) {
// 								Chess.activeBoard.getChessPieces()
// 										.remove(Chess.activeBoard.getChessPiece(leftCol, getRow()));
// 								Chess.activeBoard.initStateOfBoard();
// 								return true;
// 							}
// 						}
// 					}
// 				}
// 			}
// 			if (++rightCol <= 'h') {
// 				if (Chess.activeBoard.getChessPiece(rightCol, getRow()) instanceof Pawn) {
// 					if (((Pawn) Chess.activeBoard.getChessPiece(rightCol, getRow())).isEnPassant()) {
// 						if (Chess.activeBoard.getCell(rightCol, getRow()).contains("w")) {
// 							if (intCol == rightCol && intRow == getRow() - 1) {
// 								Chess.activeBoard.getChessPieces()
// 										.remove(Chess.activeBoard.getChessPiece(rightCol, getRow()));
// 								Chess.activeBoard.initStateOfBoard();
// 								return true;
// 							}
// 						}
// 					}
// 				}
// 			}
// 		}
// 		return false;
// 	}

// 	/**
// 	 * Checks if the pawn in in a valid position to be promoted
// 	 * 
// 	 * @param curRow The row in which the pawn resides
// 	 * @return Returns true if the pawn in in a valid position to be promoted
// 	 */
// 	public boolean checkForPromotion(int curRow) {
// 		if (getChessPieceName().equals("wp")) {
// 			if (curRow == 8)
// 				return true;
// 		} else if (getChessPieceName().equals("bp")) {
// 			if (curRow == 1)
// 				return true;
// 		}
// 		return false;
// 	}

// 	/**
// 	 * Getter for enpassant
// 	 * 
// 	 * @return Returns enpassant status
// 	 */
// 	public boolean isEnPassant() {
// 		return enPassant;
// 	}

// 	/**
// 	 * Setter for enpassant
// 	 * 
// 	 * @param enPassant Set status of enpassant
// 	 */
// 	public void setEnPassant(boolean enPassant) {
// 		this.enPassant = enPassant;
// 	}

// 	/**
// 	 * Getter for numOfEnPassantTurns
// 	 * 
// 	 * @return Returns numOfEnPassantTurns
// 	 */
// 	public int getNumOfEnPassantTurns() {
// 		return numOfEnPassantTurns;
// 	}

// 	/**
// 	 * Increments the number of turns the piece has been enpassant
// 	 */
// 	public void incrementEnPassantTurns() {
// 		numOfEnPassantTurns++;
// 	}
// }
