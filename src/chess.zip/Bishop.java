package chess;

public class Bishop {
    
}
