package chess;

public class Queen {
    
}
