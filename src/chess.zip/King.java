package chess;

public class King {
    
}
