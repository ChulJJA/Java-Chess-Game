package chess;

public class Knight {
    
}
