package chess;

import chess.ReturnPiece.PieceType;

public abstract class Piece {
	private PieceType piece_type;
	private char col;
	private int row;

	public Piece(PieceType piece_type, char col, int row) {
		super();
		this.piece_type = piece_type;
		this.col = col;
		this.row = row;
	}

	public abstract boolean IsMoveValid(char curCol, int curRow, char intCol, int intRow);

	public abstract boolean ValidMoveCheck(char curCol, int curRow, char intCol, int intRow);

	public PieceType GetPieceType() {
		return piece_type;
	}

	public void SetPieceType(PieceType piece_type) {
		this.piece_type = piece_type;
	}

	public char GetColumn() {
		return col;
	}

	public void SetColumn(char col) {
		this.col = col;
	}

	public int GetRow() {
		return row;
	}

	public void SetRow(int row) {
		this.row = row;
	}

	public void SetColRow(char col, int row) {
		this.col = col;
		this.row = row;
	}
}
